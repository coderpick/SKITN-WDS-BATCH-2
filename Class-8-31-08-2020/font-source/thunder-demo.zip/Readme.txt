Hello,

Thank for downloading THUNDER SCRIPT.
If there is a problem, question, or anything about my fonts, please sent an email to falahudin234@gmail.com

 

This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/salmanmashudi

Link to purchase full version and commercial license: 
https://fontbundles.net/hasta-type/211997-thunder-script#gtmPos=3&gtmList=15

Thanks,

Hasta Type 